# RainfallTimeSeries
Information about time series of several locations
