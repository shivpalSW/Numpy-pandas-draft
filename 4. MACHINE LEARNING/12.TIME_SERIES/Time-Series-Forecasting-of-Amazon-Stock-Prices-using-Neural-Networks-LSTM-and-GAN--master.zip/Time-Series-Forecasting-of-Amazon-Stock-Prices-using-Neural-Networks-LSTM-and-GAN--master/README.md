# Time-Series-Forecasting-of-Amazon-Stock-Prices-using-Neural-Networks-LSTM-and-GAN-
Project analyzes Amazon Stock data using Python. Feature Extraction is performed and ARIMA and Fourier series models are made. LSTM is used with multiple features to predict stock prices and then sentimental analysis is performed using news and reddit sentiments.  GANs are used to predict stock data too where Amazon data is taken from an API as Generator and CNNs are used as discriminator. 


IF THE NOTEBOOKS DONT OPEN ON GITHUB VIEW THEM ON THIS SITE: 
https://nbviewer.jupyter.org/
Copy the Jupyter notebooks github URL in this site and view them
