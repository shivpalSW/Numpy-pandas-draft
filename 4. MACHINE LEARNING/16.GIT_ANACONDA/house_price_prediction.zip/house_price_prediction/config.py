import os

PORT_NUMBER = 5004
COLUMN_NAMES_JSON_PATH = r'artifacts\x_columns.json'
MODEL_FILE = r'artifacts\banglore_hpp.pickle'
LOG_FILE = r'logs\newfile.log'

database_name = 'project_db'
mongodb_port = 27017
