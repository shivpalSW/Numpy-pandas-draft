# house_price_prediction
# Predict the price using:
* location
* total_sqft
* bhk
* bath

# How to run the file

```python
python run.py
```