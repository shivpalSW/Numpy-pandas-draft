#!/usr/bin/env python
# coding: utf-8

# In[1]:


def mul(a,b):
    return a*b


# In[2]:


def add(a,b):
    return a+b


# In[3]:


print("Hi")


# In[ ]:




