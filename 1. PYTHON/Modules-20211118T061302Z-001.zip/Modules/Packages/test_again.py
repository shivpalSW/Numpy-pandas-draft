#!/usr/bin/env python
# coding: utf-8

# In[1]:


def mul(a,b):
    return a*b


# In[ ]:


def add(a,b):
    return a+b


# In[2]:


mul(3,4)


# In[ ]:




